/*
 * types.h
 *
 * Created: 10/10/2022 23:20:40
 *  Author: s-abd
 */ 


#ifndef TYPES_H_
#define TYPES_H_

typedef enum {no_err, gpio_err, intrpt_err, timr_err} EN_error;

#endif /* TYPES_H_ */